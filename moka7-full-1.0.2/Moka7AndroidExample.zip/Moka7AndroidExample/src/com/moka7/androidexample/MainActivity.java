package com.moka7.androidexample;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;
import Moka7.*;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		
        LocalBroadcastManager.getInstance(this).registerReceiver(notifyTextReceiver,
      	      new IntentFilter("notifyText"));
	}

    @Override
    protected void onDestroy() {
      // Unregister since the activity is about to be closed.
      LocalBroadcastManager.getInstance(this).unregisterReceiver(notifyTextReceiver);
      super.onDestroy();
    }
    
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}

	public void cmdRead_onClick (View v) {
		PlcConnection p = new PlcConnection();
		p.read = true;
		new Thread(p).start();
	}

	public void cmdWrite_onClick (View v) {
		PlcConnection p = new PlcConnection();
		p.write = true;
		new Thread(p).start();
	}

	public void connectionModeChange_onClick (View v) {
		View grpRackSlot = findViewById(R.id.grpRack);
		View grpTSAP = findViewById(R.id.grpTSAP);
		
		int selectedConnectionModeRadio = ((RadioGroup) findViewById(R.id.grpConnectionMode)).getCheckedRadioButtonId();
		System.out.println(String.format("Connection mode %d", selectedConnectionModeRadio));
		switch (selectedConnectionModeRadio) {
		case R.id.rdbRackSlot: //Rack/Slot
			grpRackSlot.setVisibility(View.VISIBLE);
			grpTSAP.setVisibility(View.GONE);
			break;
		case R.id.rdbTSAP: //TSAP
			grpRackSlot.setVisibility(View.GONE);
			grpTSAP.setVisibility(View.VISIBLE);	
			break;
		}
	}
	
	private BroadcastReceiver notifyTextReceiver = new BroadcastReceiver() {
  	  @Override
  	  public void onReceive(Context context, Intent intent) {
  	    Toast t = Toast.makeText(getApplicationContext(), intent.getStringExtra("Message"), Toast.LENGTH_LONG);
  	    t.show();
  	  }
  	};
  	
    private class PlcConnection implements Runnable{
    	private final S7Client Client;
    	public boolean read=false;
    	public boolean write=false;
    	
    	public PlcConnection(){
    		Client = new S7Client();
    	}
    	
    	public void run() {
    		String IpAddr = "";
        	int LocTSAP = 0;
        	int RemTSAP = 0;
        	int selectedAreaRadio = 0;
        	int selectedArea = S7.S7AreaPE;
        	int dBNumber = 0;
        	int offset = 0;
        	int rack = 0;
        	int slot = 2;
        	boolean useTSAP = true;
        	
    		//collect connection data
    		try {
				EditText t = (EditText) findViewById(R.id.txtAddress);
				IpAddr = t.getText().toString();
				switch (((RadioGroup) findViewById(R.id.grpConnectionMode)).getCheckedRadioButtonId()) {
				case R.id.rdbRackSlot:
					t = (EditText) findViewById(R.id.txtRack);
					rack = Integer.parseInt(t.getText().toString());
					t = (EditText) findViewById(R.id.txtSlot);
					slot = Integer.parseInt(t.getText().toString());
					useTSAP = false;
					break;
				default :
					t = (EditText) findViewById(R.id.txtLocalTSAP);
					LocTSAP = Integer.parseInt(t.getText().toString(),16);
					t = (EditText) findViewById(R.id.txtRemoteTSAP);
					useTSAP = true;
				}

				RemTSAP = Integer.parseInt(t.getText().toString(),16);
				selectedAreaRadio = ((RadioGroup) findViewById(R.id.grpArea)).getCheckedRadioButtonId();
				switch (selectedAreaRadio) {
				case R.id.rdbAreaInput: //Inputs
					selectedArea = S7.S7AreaPE;
					break;
				case R.id.rdbAreaOutput: //Outputs
					selectedArea = S7.S7AreaPA;
					break;
				case R.id.rdbAreaMerker: //Merker
					selectedArea = S7.S7AreaMK;
					break;
				case R.id.rdbAreaDB: //DB
					selectedArea = S7.S7AreaDB;
					t = (EditText) findViewById(R.id.txtDBNumber);
					dBNumber = Integer.parseInt(t.getText().toString());
					break;
				}
				t = (EditText) findViewById(R.id.txtOffset);
				offset = Integer.parseInt(t.getText().toString());
			} catch (NumberFormatException e) {
				e.printStackTrace();
				Intent i = new Intent("notifyText");
				i.putExtra("Message", String.format("Error parsing parameters: %s", e.toString()));
				LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
			}
    		//connect to the plc
			int res = 0;
    		if (useTSAP) {
	    		Client.SetConnectionParams(IpAddr, LocTSAP, RemTSAP);
				res=Client.Connect();
			}
    		else {
    			Client.SetConnectionType(S7.OP);
    			res=Client.ConnectTo(IpAddr, rack, slot);
    		}
			if (res==0){
				System.out.println(String.format("%s - Connection OK", IpAddr));
				if (read) {
					byte[] data = new byte[1];
					res = Client.ReadArea(selectedArea, dBNumber, offset, 1, data);
					if (res==0) {
						Intent i = new Intent("notifyText");
						i.putExtra("Message", String.format("Read value: %d - %d - %d - %d", data[0], selectedArea, dBNumber, offset));
						LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
					}
					else {
						Intent i = new Intent("notifyText");
						i.putExtra("Message", String.format("Read error: %d - %s", res, S7Client.ErrorText(res)));
						LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);						
					}
				}
				else if (write) {
					byte[] data = new byte[1];
					EditText t = (EditText) findViewById(R.id.txtValue);
					data[0] = (byte) Integer.parseInt(t.getText().toString(), 16);
					System.out.println(String.format("%s - Writing %d to area %d, number %d, offset %d", IpAddr, data[0], selectedArea, dBNumber, offset));
					res = Client.WriteArea(selectedArea, dBNumber, offset, 1, data);
					if (res == 0) {
						Intent i = new Intent("notifyText");
						i.putExtra("Message", String.format("Write OK"));
						LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
					}
					else {
						Intent i = new Intent("notifyText");
						i.putExtra("Message", String.format("Write error: %d - %s", res, S7Client.ErrorText(res)));
						LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
					}
				}
				else {
					Intent i = new Intent("notifyText");
					i.putExtra("Message", "Connection OK");
					LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
				}
			}
			else {
				String err = String.format("%s - Connection error: %x - %s", IpAddr, res, S7Client.ErrorText(res));
				System.out.println(err);
				Intent i = new Intent("notifyText");
				i.putExtra("Message", err);
				LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
			}    				
    	}
    }
}
